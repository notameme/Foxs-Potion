using Terraria.ModLoader;

namespace FoxsPotion
{
	class FoxsPotion : Mod
	{
		public FoxsPotion()
		{
		}
	}
}
